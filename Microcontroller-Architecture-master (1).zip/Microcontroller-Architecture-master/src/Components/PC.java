package Components;

public class PC {
    public static int pc;

    public PC(){
        pc = 0;
    }

    public int getPc(){
        return pc;
    }

    public int increment(){
        return pc +4;
    }

}
